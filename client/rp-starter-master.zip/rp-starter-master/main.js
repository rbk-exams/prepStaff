function square(x) {
  return x * x;
}
